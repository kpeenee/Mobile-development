﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace mobileApp
{
    public class Flashcard
    {
        [JsonProperty(PropertyName = "id")]
        public string Name { get; set; }
        public string Subject { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        public bool IsAnswered { get; set; }
        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
        public Flashcard(string name, string Sub, string Ques, string Ans, bool IsAns) => (Name, Subject, Question, Answer, IsAnswered) = (name, Sub, Ques, Ans, IsAns);
    }
}
